#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @author YuYawei
 * @Description: ${Description}
 * @CreateDate ${YEAR}-${MONTH}-${DAY} ${TIME} 
 */
public enum ${NAME} {
}
